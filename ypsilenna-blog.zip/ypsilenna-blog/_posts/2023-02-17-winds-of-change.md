---
layout: post
title: "Winds of change" 
date: 2023-02-17
categories: [microblog]
tags: [news] 
authors: [Kornelia]
moods: 😍
---
I am remaking my microblog a little so that my friends can get notifications through WordPress subscriptions. Love you guys ♥