---
layout: post
title: "The effect being locked away on WordPress has on a person" 
date: "2023-02-17"
categories: [microblog]
tags: [personal] 
authors: [Me]
moods: 🤪
---
Me after 3+ months on social media: I feel so demotivated 🙁
Me after 3+ days on my website: I made an RPG themed character panel for my OCs.
Coming soon!